// LEADS IMÓVEIS | CONFIGURAÇÃO SUPABASE DO SITE
// Nome obrigatório do arquivo: supabase-config.js
// Coloque este arquivo na raiz do GitHub, junto com index.html.

const LEADS_SUPABASE_URL = 'https://zyfbgydbwsvbaogbxzrd.supabase.co';
const LEADS_SUPABASE_ANON_KEY = 'sb_publishable_AP670pbIpkD_KleT7VaQ3Q_BTsBh8yh';

if (!window.supabase) {
  console.error('Leads Imóveis: biblioteca Supabase não carregou.');
} else {
  window.leadsSupabaseClient = window.supabase.createClient(
    LEADS_SUPABASE_URL,
    LEADS_SUPABASE_ANON_KEY
  );

  window.supabaseClient = window.leadsSupabaseClient;

  console.log('Leads Imóveis: Supabase conectado com sucesso.');
}
